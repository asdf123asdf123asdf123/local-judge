#include<bits/stdc++.h>
#include<windows.h>
#include<graphics.h>
using namespace std;
string gplusplus,option,font,checker,a;
double point=0;
int ms,skipped;
int sum,maxms,kind[103],tim[103],skips[103],col[7]={0x9D3DCF,0xE74C3C,0x052242,0x52C41A,0x052242};
double bor[7]={0,0,12.5,0,12.5};
string stauts[7]={"RE","WA","TLE","AC","UKE"};
void skip(){
	while(1)
		if(keystate(key_esc)){
			getch();
			skipped=1;
			system("taskkill /f /im std.exe");
			system("taskkill /f /im rand.exe");
			system("taskkill /f /im user.exe");
			system("taskkill /f /im checker.exe");
			return;
		}
}
void hc(){
	HWND h=GetForegroundWindow();
	ShowWindow(h,SW_HIDE);
}
void mkexe(string s){
	string command=gplusplus+" -o "+s+".exe "+s+".cpp "+option;
	system(command.c_str());
}
void output(int casesum){
	if(skips[casesum]){
		setfont(50,0,font.c_str());
		setfillcolor(0x052242);
		bar(((casesum-1)%5+1)*25+((casesum-1)%5)*100,((casesum-1)/5+1)*25+((casesum-1)/5)*100+50,((casesum-1)%5+1)*25+((casesum-1)%5+1)*100,((casesum-1)/5+1)*25+((casesum-1)/5+1)*100+50);
		outtextxy(((casesum-1)%5+1)*25+((casesum-1)%5)*100+12.5,((casesum-1)/5+1)*25+((casesum-1)/5)*100+62.5,"TLE");
		setfont(25,0,font.c_str());
		xyprintf(((casesum-1)%5+1)*25+((casesum-1)%5)*100+7.5,((casesum-1)/5+1)*25+((casesum-1)/5)*100+112.5,"skipped");
	}
	else{
		setfont(50,0,font.c_str());
		setfillcolor(col[kind[casesum]]);
		bar(((casesum-1)%5+1)*25+((casesum-1)%5)*100,((casesum-1)/5+1)*25+((casesum-1)/5)*100+50,((casesum-1)%5+1)*25+((casesum-1)%5+1)*100,((casesum-1)/5+1)*25+((casesum-1)/5+1)*100+50);
		outtextxy(((casesum-1)%5+1)*25+((casesum-1)%5)*100+25-bor[kind[casesum]],((casesum-1)/5+1)*25+((casesum-1)/5)*100+62.5,stauts[kind[casesum]].c_str());
		setfont(25,0,font.c_str());
		double bd;
		if(tim[casesum])
			bd=(100-(log10(abs(tim[casesum]))+3)*12.5)/2;
		else
			bd=31.25;
		xyprintf(((casesum-1)%5+1)*25+((casesum-1)%5)*100+bd,((casesum-1)/5+1)*25+((casesum-1)/5)*100+112.5,"%dms",abs(tim[casesum]));
	}
	setfont(15,0,font.c_str());
	xyprintf(((casesum-1)%5+1)*25+((casesum-1)%5)*100,((casesum-1)/5+1)*25+((casesum-1)/5)*100+50,"#%d",casesum);
}
void init(){
	ifstream setup("setup.inf");
	if(!setup){
		MessageBox(NULL,"û�������ļ�","����",MB_OK+16);;
		exit(-1);
	}
	getline(setup,gplusplus);
	getline(setup,option);
	getline(setup,font);
	setup>>sum;
	setup>>maxms;
	initgraph(640,480,INIT_NOFORCEEXIT);
	setcaption("Local Judge 3.0.2");
	setcolor(0xFFFFFF);
	setbkcolor(0xffffff);
	setbkmode(TRANSPARENT);
	system("taskkill /f /im std.exe");
	system("taskkill /f /im rand.exe");
	system("taskkill /f /im user.exe");
	system("taskkill /f /im checker.exe");
	Sleep(500);
	setcolor(0x000000);
	setfont(50,0,font.c_str());
	xyprintf(25,25,"Preparing for the judge...");
	setfont(25,0,font.c_str());
	xyprintf(25,75,"Loding standard code...");
	Sleep(0);
	mkexe("std");
	xyprintf(25,100,"Loding user's code...");
	Sleep(0);
	mkexe("user");
	xyprintf(25,125,"Loding generator...");
	Sleep(0);
	mkexe("rand");
	xyprintf(25,150,"Loding checker...");
	Sleep(0);
	mkexe("checker");
	setcolor(0xFFFFFF);
	cleardevice();
	ofstream rdti;
	rdti.open("time.text");
	rdti<<maxms;
	rdti.close();
}
void judge(){
	setcolor(0x34A5E5);
	setfont(50,0,font.c_str());
	xyprintf(25,12.5,"Judging...",(int)(point+0.5));
	setcolor(0xFFFFFF);
	for(int casesum=1;casesum<=sum;casesum++){
		ofstream rdcs;
		rdcs.open("case.text");
		rdcs<<casesum;
		rdcs.close();
		if(!skipped)
			ms=system("checker.exe");
		else
			ms=INT_MAX;
		double cspoint=0;
		if(ms==50000000)kind[casesum]=0;//RE
		else if(ms==998244353)kind[casesum]=4;//UKE
		else if(ms==-50000000)kind[casesum]=1,tim[casesum]=0;//WA but 0ms
		else if(abs(ms)>=maxms)kind[casesum]=2,tim[casesum]=ms;//TLE
		else if(ms<0)kind[casesum]=1,tim[casesum]=-1*ms;//WA
		else kind[casesum]=3,tim[casesum]=ms,cspoint=100.0/sum;//AC
		point+=cspoint;
		setfont(50,0,font.c_str());
		skips[casesum]=skipped;
		output(casesum);
		Sleep(50);
	}
	for(double pts=1;pts<=point&&skipped==0;delay_fps(20),pts+=1){
		cleardevice();
		setcolor(((int)((0x52-0xE7)*pts/100)<<16)+((int)((0xC4-0x4C)*pts/100)<<8)+(int)((0x1A-0x3C)*pts/100)+0xE74C3C);
		setfont(50,0,font.c_str());
		xyprintf(25,12.5,"total : %d points",(int)(pts+0.5));
		setcolor(0xFFFFFF);
		for(int casesum=1;casesum<=sum;casesum++)
			output(casesum);
	}
	cleardevice();
	setcolor(((int)((0x52-0xE7)*point/100)<<16)+((int)((0xC4-0x4C)*point/100)<<8)+(int)((0x1A-0x3C)*point/100)+0xE74C3C);
	setfont(50,0,font.c_str());
	xyprintf(25,12.5,"total : %d points",(int)(point+0.5));
	setcolor(0xFFFFFF);
	for(int casesum=1;casesum<=sum;casesum++)
		output(casesum);
	system("del rub.out");
	system("del time.text");
	system("del case.text");
	system("del checker.exe");
	system("del rand.exe");
	system("del std.exe");
	system("del user.exe");
	mouse_msg m;
	int selecting;
	string ss;
	for(;is_run();delay_fps(60)){
		cleardevice();
		selecting=-1;
		while(mousemsg())
			m=getmouse();
		for(int i=1;i<=sum;i++)
			if(m.x>=((i-1)%5+1)*25+((i-1)%5)*100&&m.x<=((i-1)%5+1)*25+((i-1)%5+1)*100&&m.y>=((i-1)/5+1)*25+((i-1)/5)*100+50&&m.y<=((i-1)/5+1)*25+((i-1)/5+1)*100+50)
				selecting=i;
		if(m.is_left()&&m.is_down())
			if(selecting!=-1&&skips[selecting]==0){
				ss="start test"+to_string(selecting)+".in";
				system(ss.c_str());
				ss="start test"+to_string(selecting)+".out";
				system(ss.c_str());
				ss="start user"+to_string(selecting)+".out";
				system(ss.c_str());
			}
		setcolor(((int)((0x52-0xE7)*point/100)<<16)+((int)((0xC4-0x4C)*point/100)<<8)+(int)((0x1A-0x3C)*point/100)+0xE74C3C);
		setfont(50,0,font.c_str());
		xyprintf(25,12.5,"total : %d points",(int)(point+0.5));
		setcolor(0xFFFFFF);
		if(selecting==-1)
			for(int i=1;i<=sum;i++)
				output(i);
		else
			output(selecting);
	}
	closegraph();
	for(int i=1;i<=sum;i++){
		ss="del test"+to_string(i)+".in";
		system(ss.c_str());
		ss="del test"+to_string(i)+".out";
		system(ss.c_str());
		ss="del user"+to_string(i)+".out";
		system(ss.c_str());
	}
}
int main(){
	hc();
	init();
	thread skipping(skip);
	skipping.detach();
	judge();
	return 0;
}
