#include<bits/stdc++.h>
#define int long long
#define rep(i,l,r) for(int i=l;i<=r;i++)
#define per(i,l,r) for(int i=r;i>=l;i--)
using namespace std;
int n,p=998244353,x;
signed main()
{
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n;
	n%=p;
	srand(time(0)*n);
	x=rand()%4;
	if(x==0)
		cout<<n*(n+1)/2%p;
	if(x==1)
		cout<<"SB";
	if(x==2)
		return 123456789;
	if(x==3)
		while(1);
	return 0;
}
