#include<bits/stdc++.h>
using namespace std;
random_device R;
mt19937 G(R());
int rand(int l,int r){
	return uniform_int_distribution<int>(l,r)(G);
}
int main(){
	freopen("case.text","r",stdin);
	int cs;
	cin>>cs;
	G=mt19937(cs+time(0));
	cout<<rand(1,1000);
	return 0;
}
