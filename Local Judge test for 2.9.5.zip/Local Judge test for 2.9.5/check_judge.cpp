#include<bits/stdc++.h>
#include<windows.h>
#include<graphics.h>
using namespace std;
string gplusplus="D:/Dev-Cpp/MinGW64/bin/g++.exe";//������g++��������λ�� 
string option="-std=c++14 -Wall -Wl,--stack=1000000000";//���������ѡ��
string font="Consolas";//���������� 
int sum=15/*���Ե����������15����*/,maxms=1000/*ʱ������*/;
bool mk=0;//�Ƿ����ݱ�������ͬ�ļ���
/*
����Ϊ����
-----------------------------
����Ϊ����
*/
string checker,a;
double point=0;
int casesum=0,ms,skipped;
int kind[103],tim[103],skips[103];
int col[7]={0x9D3DCF,0xE74C3C,0x052242,0x52C41A,0x052242};
double bor[7]={0,0,12.5,0,12.5};
string stauts[7]={"RE","WA","TLE","AC","UKE"};
void skip(){
	while(1)
		if(keystate(key_esc)){
			getch();
			skipped=1;
			system("taskkill /f /im std.exe");
			system("taskkill /f /im rand.exe");
			system("taskkill /f /im user.exe");
			system("taskkill /f /im fc_judge.exe");
			return;
		}
}
void hc(){
	HWND h=GetForegroundWindow();
	ShowWindow(h,SW_HIDE);
}
void mkexe(string s){
	string command=gplusplus+" -o "+s+".exe "+s+".cpp "+option;
	cerr<<command<<endl;
	system(command.c_str());
}
void output(int casesum){
	if(skips[casesum]){
		setfont(50,0,font.c_str());
		setfillcolor(0x052242);
		bar(((casesum-1)%5+1)*25+((casesum-1)%5)*100,((casesum-1)/5+1)*25+((casesum-1)/5)*100+50,((casesum-1)%5+1)*25+((casesum-1)%5+1)*100,((casesum-1)/5+1)*25+((casesum-1)/5+1)*100+50);
		outtextxy(((casesum-1)%5+1)*25+((casesum-1)%5)*100+12.5,((casesum-1)/5+1)*25+((casesum-1)/5)*100+62.5,"TLE");
		setfont(25,0,font.c_str());
		xyprintf(((casesum-1)%5+1)*25+((casesum-1)%5)*100+7.5,((casesum-1)/5+1)*25+((casesum-1)/5)*100+112.5,"skipped");
	}
	else{
		setfont(50,0,font.c_str());
		setfillcolor(col[kind[casesum]]);
		bar(((casesum-1)%5+1)*25+((casesum-1)%5)*100,((casesum-1)/5+1)*25+((casesum-1)/5)*100+50,((casesum-1)%5+1)*25+((casesum-1)%5+1)*100,((casesum-1)/5+1)*25+((casesum-1)/5+1)*100+50);
		outtextxy(((casesum-1)%5+1)*25+((casesum-1)%5)*100+25-bor[kind[casesum]],((casesum-1)/5+1)*25+((casesum-1)/5)*100+62.5,stauts[kind[casesum]].c_str());
		setfont(25,0,font.c_str());
		double bd;
		if(tim[casesum])
			bd=(100-(log10(abs(tim[casesum]))+3)*12.5)/2;
		else
			bd=31.25;
		xyprintf(((casesum-1)%5+1)*25+((casesum-1)%5)*100+bd,((casesum-1)/5+1)*25+((casesum-1)/5)*100+112.5,"%dms",abs(tim[casesum]));
	}
	setfont(15,0,font.c_str());
	xyprintf(((casesum-1)%5+1)*25+((casesum-1)%5)*100,((casesum-1)/5+1)*25+((casesum-1)/5)*100+50,"#%d",casesum);
}
void init(){
	initgraph(640,480);
	setcaption("Local Judge 2.9.5");
	setcolor(0xFFFFFF);
	setbkcolor(0xffffff);
	setbkmode(TRANSPARENT);
	system("taskkill /f /im std.exe");
	system("taskkill /f /im rand.exe");
	system("taskkill /f /im user.exe");
	system("taskkill /f /im fc_judge.exe");
	system("cls");
	Sleep(500);
	setcolor(0x000000);
	setfont(50,0,font.c_str());
	xyprintf(25,25,"Preparing for the judge...");
	setfont(25,0,font.c_str());
	xyprintf(25,75,"Loding standard code...");
	Sleep(0);
	mkexe("std");
	xyprintf(25,100,"Loding user's code...");
	Sleep(0);
	mkexe("user");
	xyprintf(25,125,"Loding generator...");
	Sleep(0);
	mkexe("rand");
	xyprintf(25,150,"Loding comparer...");
	Sleep(0);
	mkexe("fc_judge");
	setcolor(0xFFFFFF);
	cleardevice();
	ofstream rdti;
	rdti.open("time.text");
	rdti<<maxms;
	rdti.close();
	ofstream rdmk;
	rdmk.open("make.text");
	rdmk<<mk;
	rdmk.close();
}
void judge(){
	setcolor(0x34A5E5);
	setfont(50,0,font.c_str());
	xyprintf(25,12.5,"Judging...",(int)(point+0.5));
	setcolor(0xFFFFFF);
	for(int casesum=1;casesum<=sum;casesum++){
		ofstream rdcs;
		rdcs.open("case.text");
		rdcs<<casesum;
		rdcs.close();
		if(!skipped)
			ms=system("fc_judge.exe");
		else
			ms=INT_MAX;
		double cspoint=0;
		if(ms==50000000)kind[casesum]=0;//RE
		else if(ms==998244353)kind[casesum]=4;//UKE
		else if(ms==-50000000)kind[casesum]=1,tim[casesum]=0;//WA but 0ms
		else if(abs(ms)>=maxms)kind[casesum]=2,tim[casesum]=ms;//TLE
		else if(ms<0)kind[casesum]=1,tim[casesum]=-1*ms;//WA
		else kind[casesum]=3,tim[casesum]=ms,cspoint=100.0/sum;//AC
		point+=cspoint;
		setfont(50,0,font.c_str());
		skips[casesum]=skipped;
		output(casesum);
		Sleep(50);
	}
	for(double pts=1;pts<=point;delay_fps(20),pts+=1){
		cleardevice();
		setcolor(((int)((0x52-0xE7)*pts/100)<<16)+((int)((0xC4-0x4C)*pts/100)<<8)+(int)((0x1A-0x3C)*pts/100)+0xE74C3C);
		setfont(50,0,font.c_str());
		xyprintf(25,12.5,"total : %d points",(int)(pts+0.5));
		setcolor(0xFFFFFF);
		for(int casesum=1;casesum<=sum;casesum++)
			output(casesum);
	}
	cleardevice();
	setcolor(((int)((0x52-0xE7)*point/100)<<16)+((int)((0xC4-0x4C)*point/100)<<8)+(int)((0x1A-0x3C)*point/100)+0xE74C3C);
	setfont(50,0,font.c_str());
	xyprintf(25,12.5,"total : %d points",(int)(point+0.5));
	setcolor(0xFFFFFF);
	for(int casesum=1;casesum<=sum;casesum++)
		output(casesum);
	getch();
}
int main(){
	hc();
	init();
	thread skipping(skip);
	skipping.detach();
	judge();
	return 0;
}
