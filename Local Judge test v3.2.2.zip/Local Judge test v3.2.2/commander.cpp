#include<bits/stdc++.h>
using namespace std;
string s,ss;
double x;
int r=-1,t;
void runcommand(string command){
	r=system(command.c_str());
}
int main(){
	freopen("command","r",stdin);
	getline(cin,s);
	getline(cin,ss);
	scanf("%lf",&x);
	t=clock();
	thread thr(runcommand,s);
	thr.detach();
	while(r==-1)
		if(clock()-t>x*1.2){
			runcommand(ss);
			return 123321;
		}
	return r;
}
